%%timeit
#test loop
first_run = True
for f in stream:
    if first_run:
        # Get the intensity component of the image (a trick to get black and white images)
        I = f.array[:, :, 0]
        # Reset the buffer for the next image
        rawCapture.truncate(0)
        # Select a horizontal line in the middle of the image
        L = I[line, :]
        # To filter the noise in the image we use a 3rd order Butterworth filter
        b, a = butter(3, 0.02) 
        # Smooth the transitions so we can detect the peaks 
        Lf = filtfilt(b, a, L)
        # Due to the noise in the image the algorithm finds many peaks heigher than 0.5
        p = find_peaks(Lf, height=100)
        # calculations
        # print(p)
        pid.update(p[0][0])
        feedback = int(pid.output + 1500000)
        pwm1.duty_cycle = feedback
        #print(feedback)
        first_run = False
    else:
        # capture new image 
        if(''' 2nd image similar to 1st'''):
            
            old = current
            current = get_new
            process new
        else:
            #ignore the new image -- it is not the center line or there are no peaks
    
    
    if(pwm0.duty_cycle < 1050000):
        plt.imshow(I)
        break